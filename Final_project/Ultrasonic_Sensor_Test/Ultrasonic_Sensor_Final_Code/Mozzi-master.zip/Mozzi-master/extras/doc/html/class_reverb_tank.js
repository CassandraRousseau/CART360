var class_reverb_tank =
[
    [ "ReverbTank", "class_reverb_tank.html#a3ca18b03d045df164462338f6ed0648c", null ],
    [ "next", "class_reverb_tank.html#a4930ae7a871dba610fb141d7ab83d827", null ],
    [ "setEarlyReflections", "class_reverb_tank.html#a6d27d8a02ec9551a5338bb1ba4bf9af2", null ],
    [ "setFeebackLevel", "class_reverb_tank.html#a91eeb601e42df576737f0d44dc73c653", null ],
    [ "setLoopDelays", "class_reverb_tank.html#a0b348b630007a5cbda8b314d0c8dd604", null ]
];