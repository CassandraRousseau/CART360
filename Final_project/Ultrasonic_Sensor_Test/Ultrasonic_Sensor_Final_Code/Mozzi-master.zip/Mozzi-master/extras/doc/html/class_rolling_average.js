var class_rolling_average =
[
    [ "RollingAverage", "class_rolling_average.html#a11cf7b9e1278648b1eb10e5534fe3e29", null ],
    [ "add", "class_rolling_average.html#a9c9f4083b726ed046c97a91535486317", null ],
    [ "next", "class_rolling_average.html#a23c4b93258faace0c7ee60eb395d2c4b", null ]
];