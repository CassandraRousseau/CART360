var searchData=
[
  ['core',['Core',['../group__core.html',1,'']]]
];
