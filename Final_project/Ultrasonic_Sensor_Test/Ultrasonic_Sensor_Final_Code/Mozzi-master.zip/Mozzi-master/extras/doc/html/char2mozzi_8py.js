var char2mozzi_8py =
[
    [ "char2mozzi", "char2mozzi_8py.html#aabd66d57c9b80e218d455346db80d587", null ]
];